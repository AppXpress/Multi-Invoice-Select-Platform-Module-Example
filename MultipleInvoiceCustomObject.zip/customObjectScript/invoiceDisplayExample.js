function populateOnCreate(co, eventName, params) {

    var invoiceRootType = new Object();
    invoiceRootType.reference = co.anchor.refNumber;
    invoiceRootType.rootType = "Shipment";
    invoiceRootType.rootId = co.anchor.transactionId;
    co.Invoice = invoiceRootType;
    Providers.getPersistenceProvider().save(co);
    populateOnSave(co, eventName, params);
}


function populateOnSave(co, eventName, params){
    // Get the primary object's Invoice and any embedded objects' invoices and pass them to our function that
    // calculates the amounts in the Invoices' assoicated orders
    var totalAmount = 0;

    totalAmount += Number(getAssociatedOrderTotals(co.anchor.transactionId));

    // If there are embedded objects, loop through them and add their associated order amounts
    embeddedInvoices = co.AdditionalInvoices;
    if(embeddedInvoices){
        var i = 0;
        for(i = 0; i < embeddedInvoices.length; i++){
            totalAmount +=  Number(getAssociatedOrderTotals(embeddedInvoices[i].Invoice.rootId));
        }
    }


    co.InvoicesTotalAmounts = Number(totalAmount);
    Providers.getPersistenceProvider().save(co);

    //var invoice = Providers.getPersistenceProvider().createFetchRequest("InvoiceDetail", 310, co.anchor.transactionId).execute();
    //var ordersOnInvoice = invoice.orderReference;
    //var ordersTotalAmount = 0;
    //if (ordersOnInvoice) {
    //    var i = 0;
    //    for (i = 0; i < ordersOnInvoice.length; i++) {
    //        // Get the Purchase Order's UID
    //        orderUID = ordersOnInvoice[i].orderUid;
    //        if(orderUID) {
    //            var order = Providers.getPersistenceProvider().createFetchRequest("OrderDetail", 310, orderUID).execute();
    //            ordersTotalAmount = ordersTotalAmount + order.totals.totalMerchandiseAmount;
    //        }
    //    }
    //
    //    co.InvoicesTotalAmounts = ordersTotalAmount;
    //    Providers.getPersistenceProvider().save(co);
    //}

}

function getAssociatedOrderTotals(invoiceId){
    // First let's fetch our Invoice
    var invoice = Providers.getPersistenceProvider().createFetchRequest("InvoiceDetail", 310, invoiceId).execute();

    // Then get the associated orders on the Invoice (note that orderReference is an array
    var ordersOnInvoice = invoice.orderReference;
    var ordersTotalAmount = 0;

    // Now loop through the order references, fetch each order and get the total amount on it
    if (ordersOnInvoice) {
        var i = 0;
        for (i = 0; i < ordersOnInvoice.length; i++) {
            // Get the Purchase Order's UID
            orderUID = ordersOnInvoice[i].orderUid;
            if(orderUID) {
                var order = Providers.getPersistenceProvider().createFetchRequest("OrderDetail", 310, orderUID).execute();
                ordersTotalAmount = ordersTotalAmount + order.totals.totalMerchandiseAmount;
            }
        }


    }

    return ordersTotalAmount;
}


